import { existsSync, mkdirSync, readFileSync } from 'node:fs';
import { homedir, platform } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = dirname(fileURLToPath(import.meta.url));
const configPath = join(root, 'config.json');
if (!existsSync(configPath)) throw new Error('Crie config.json a partir de config.example.json.');
const config = JSON.parse(readFileSync(configPath, 'utf8'));
for (const key of ['apiUrl', 'agentId', 'enrollmentToken']) if (!config[key]) throw new Error(`Configuração ausente: ${key}`);
const apiUrl = config.apiUrl.replace(/\/$/, '');
const allowedHosts = new Set((config.allowedHosts || []).map((host) => String(host).toLowerCase()));
const profileRoot = join(homedir(), '.horizons-panel-agent', 'profiles');
mkdirSync(profileRoot, { recursive: true });
const running = new Map();

function safeId(value) { return String(value).replace(/[^a-z0-9_-]/gi, '_').slice(0, 100); }
function chromeCandidates() {
  if (platform() === 'win32') return [
    join(process.env.PROGRAMFILES || 'C:/Program Files', 'Google/Chrome/Application/chrome.exe'),
    join(process.env['PROGRAMFILES(X86)'] || 'C:/Program Files (x86)', 'Google/Chrome/Application/chrome.exe'), 'chrome.exe',
  ];
  if (platform() === 'darwin') return ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', 'google-chrome'];
  return ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser'];
}
async function launchBrowser(connectionId, targetUrl) {
  const target = new URL(targetUrl);
  if (target.protocol !== 'https:' || !allowedHosts.has(target.hostname.toLowerCase())) {
    throw new Error(`O host ${target.hostname} não está autorizado neste agente.`);
  }
  const current = running.get(connectionId);
  if (current && !current.killed) return { reused: true, pid: current.pid };
  const profile = join(profileRoot, safeId(connectionId));
  mkdirSync(profile, { recursive: true });
  let lastError;
  for (const command of chromeCandidates()) {
    try {
      const child = spawn(command, [
        `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check',
        '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', target.toString(),
      ], { detached: false, stdio: 'ignore', windowsHide: false });
      await new Promise((resolve, reject) => {
        child.once('spawn', resolve);
        child.once('error', reject);
      });
      running.set(connectionId, child);
      child.once('exit', () => running.delete(connectionId));
      return { reused: false, pid: child.pid };
    } catch (error) { lastError = error; }
  }
  throw lastError || new Error('Google Chrome/Chromium não foi encontrado.');
}
function closeBrowser(connectionId) {
  const child = running.get(connectionId);
  if (!child || child.killed) return { closed: false };
  child.kill(); running.delete(connectionId);
  return { closed: true };
}
async function request(path, options = {}) {
  const response = await fetch(`${apiUrl}${path}`, {
    ...options,
    headers: {
      authorization: `Bearer ${config.enrollmentToken}`,
      'x-horizons-agent-id': config.agentId,
      ...(options.body ? { 'content-type': 'application/json' } : {}),
      ...options.headers,
    },
    signal: AbortSignal.timeout(20_000),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `API respondeu ${response.status}`);
  return payload;
}
async function execute(command) {
  if (command.action === 'open_browser') return launchBrowser(command.panel_connection_id, command.payload.base_url);
  if (command.action === 'close_browser') return closeBrowser(command.panel_connection_id);
  throw new Error('Comando não suportado.');
}
async function tick() {
  await request('/agent/heartbeat', { method: 'POST', body: JSON.stringify({ platform: platform(), hostname: process.env.COMPUTERNAME || process.env.HOSTNAME || null }) });
  const { command } = await request('/agent/commands/next');
  if (!command) return;
  try {
    const result = await execute(command);
    await request(`/agent/commands/${command.id}/result`, { method: 'POST', body: JSON.stringify({ ok: true, result }) });
    console.log(`[${new Date().toISOString()}] ${command.action} concluído.`);
  } catch (error) {
    await request(`/agent/commands/${command.id}/result`, { method: 'POST', body: JSON.stringify({ ok: false, error: error.message.slice(0, 1000) }) });
    console.error(`[${new Date().toISOString()}] ${command.action}: ${error.message}`);
  }
}
const interval = Math.max(3, Number(config.pollIntervalSeconds || 5)) * 1000;
console.log(`Horizons Local Panel Agent conectado. Consultando a cada ${interval / 1000}s.`);
setInterval(() => tick().catch((error) => console.error(`Conexão: ${error.message}`)), interval);
tick().catch((error) => console.error(`Conexão: ${error.message}`));
